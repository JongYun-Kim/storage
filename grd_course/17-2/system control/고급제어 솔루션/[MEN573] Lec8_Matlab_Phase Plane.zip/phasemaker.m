%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% phasemaker.m: Makes phase plots by running simulations repeatedly 
%%               with different initial conditions and plotting them 
%% 				  on the same graph
%%
%% --mike uchanski jan2000.  
%%
%%   email me if you have difficulties: guiness@vehicle.me.berkeley.edu
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Amount of time to run each simulation
tfinal = 15;



% Parameters of a rectangle of initial conditions.  Adjust here for more
% resolution, a smaller or larger "window", etc
xmin = -5;
xmax = 5;
num_xpoints = 10;

ymin = -5;
ymax = 5;
num_ypoints = 10;



% Make matrix with x and y coordinates of the ICs on perimeter of rectangle
xpoints = linspace(xmin, xmax, num_xpoints);
ypoints = linspace(ymin, ymax, num_ypoints);

ics = [ xpoints'                  ymax*ones(num_xpoints,1);   ...
        xmax*ones(num_ypoints,1)  ypoints';                   ...
        xpoints'                  ymin*ones(num_xpoints,1);   ...
        xmin*ones(num_ypoints,1)  ypoints'                    ...
        ];





% Make a linear system
A = [ -1      1     ;...
      -1      -1 ];
B = [   0         0  ]';
C = eye(2);
D = 0;
linsys = ss(A,B,C,D);





% Run simulation inside a "for" loop.  If running a linear simulation, use
% the "initial" command.  If running a nonlinear one, download "xprime.m" and 
% use the "ode23" line.  

figure(1);
hold on;           % Keep the same plot on the screen so we can overlay them
for i = 1:length(ics),

   % Choose a simulation routine
   [junk,junk,states] = initial(linsys,ics(i,:)',tfinal);  % for problem 1
   %[junk,states] = ode23('xprime',tfinal,ics(i,:)');      % for problem 3

   states = states';  % turns states into a matrix of size 2 x (n_time_points) 
   states = states;   % Insert transformation here for problem 1
   plot(states(1,:),states(2,:));
end


axis([xmin,xmax,ymin,ymax]);




	